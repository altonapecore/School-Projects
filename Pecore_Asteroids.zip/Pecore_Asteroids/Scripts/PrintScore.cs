﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrintScore : MonoBehaviour
{
    private static int score;
    GUIStyle style;

    // Camera stuff for positioning
    private Camera cam;
    private float height;
    private float width;

	// Use this for initialization
	void Start ()
    {
        // Change the style so that it matches the rest of the text on the screen
        style = new GUIStyle();
        style.fontSize = 80;
        style.normal.textColor = Color.cyan;

        // Get the score from the GameManagerScript
        score = GameManagerScript.score;

        // Do camera stuff
        cam = Camera.main;
        height = 2f * cam.orthographicSize;
        width = height * cam.aspect;
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    /// <summary>
    /// Print whatever the score is
    /// </summary>
    public void OnGUI()
    {
        GUI.TextArea(new Rect((width * 35),(height * 30), 800, 800), "Score: " + score.ToString(), style);
    }
}
