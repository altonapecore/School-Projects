﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionManager : MonoBehaviour
{
    public float enemyMinX;
    public float enemyMaxX;
    public float enemyMinY;
    public float enemyMaxY;

    public float shipMinX;
    public float shipMaxX;
    public float shipMinY;
    public float shipMaxY;

    public float bulletPointX;
    public float bulletPointY;

    // Use this for initialization
    void Start ()
    {

    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    #region ShipCollision
    /// <summary>
    /// Checks for a collision between the ship and the enemy
    /// </summary>
    /// <param name="ship"> Ship </param>
    /// <param name="enemy"> Enemy </param>
    /// <returns> Bool of whether it hit or not </returns>
    public bool ShipCollision(GameObject ship, GameObject enemy)
    {
        // Set min and max of x and y on ship
        shipMinX = ship.GetComponent<SpriteRenderer>().bounds.min.x;
        shipMaxX = ship.GetComponent<SpriteRenderer>().bounds.max.x;
        shipMinY = ship.GetComponent<SpriteRenderer>().bounds.min.y;
        shipMaxY = ship.GetComponent<SpriteRenderer>().bounds.max.y;

        // Set min and max of x and y on enemy
        enemyMaxX = enemy.GetComponent<SpriteRenderer>().bounds.max.x;
        enemyMinX = enemy.GetComponent<SpriteRenderer>().bounds.min.x;
        enemyMaxY = enemy.GetComponent<SpriteRenderer>().bounds.max.y;
        enemyMinY = enemy.GetComponent<SpriteRenderer>().bounds.min.y;

        // Draw debug lines that show the collision boxes on ship
        Debug.DrawLine(new Vector3(shipMinX, shipMinY, 0), new Vector3(shipMaxX, shipMinY, 0), Color.red);
        Debug.DrawLine(new Vector3(shipMinX, shipMinY, 0), new Vector3(shipMinX, shipMaxY, 0), Color.red);
        Debug.DrawLine(new Vector3(shipMaxX, shipMaxY, 0), new Vector3(shipMaxX, shipMinY, 0), Color.red);
        Debug.DrawLine(new Vector3(shipMaxX, shipMaxY, 0), new Vector3(shipMinX, shipMaxY, 0), Color.red);

        // Draw debug lines that show the collision boxes on enemy
        Debug.DrawLine(new Vector3(enemyMinX, enemyMinY, 0), new Vector3(enemyMaxX, enemyMinY, 0), Color.red);
        Debug.DrawLine(new Vector3(enemyMinX, enemyMinY, 0), new Vector3(enemyMinX, enemyMaxY, 0), Color.red);
        Debug.DrawLine(new Vector3(enemyMaxX, enemyMaxY, 0), new Vector3(enemyMaxX, enemyMinY, 0), Color.red);
        Debug.DrawLine(new Vector3(enemyMaxX, enemyMaxY, 0), new Vector3(enemyMinX, enemyMaxY, 0), Color.red);

        // If everything is true return true
        if (shipMinX < enemyMaxX && shipMaxX > enemyMinX && shipMaxY > enemyMinY && shipMinY < enemyMaxY)
        {
            return true;
        }

        // If not return false
        else
        {
            return false;
        }
    }
    #endregion

    #region BulletCollision
    /// <summary>
    /// Checks to see if there is a collisions between ship's bullet and enemy
    /// </summary>
    /// <param name="bullet">Ship's bullet</param>
    /// <param name="enemy">Enemy</param>
    /// <returns></returns>
    public bool BulletCollision(GameObject bullet, GameObject enemy)
    {
        // Set x and y to the center of the bullet
        bulletPointX = bullet.GetComponent<SpriteRenderer>().bounds.center.x;
        bulletPointY = bullet.GetComponent<SpriteRenderer>().bounds.center.y;
        
        // Set min and max of x and y for enemy
        enemyMaxX = enemy.GetComponent<SpriteRenderer>().bounds.max.x;
        enemyMinX = enemy.GetComponent<SpriteRenderer>().bounds.min.x;
        enemyMaxY = enemy.GetComponent<SpriteRenderer>().bounds.max.y;
        enemyMinY = enemy.GetComponent<SpriteRenderer>().bounds.min.y;

        // If true return true
        if(bulletPointX < enemyMaxX && bulletPointX > enemyMinX && bulletPointY > enemyMinY && bulletPointY < enemyMaxY)
        {
            return true;
        }

        // If false return false
        else
        {
            return false;
        }
    }
    #endregion
}
