﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletMovement : MonoBehaviour
{
    // Movement variables
    public Vector3 velocity = new Vector3(0, 0, 0);
    public Vector3 direction = new Vector3(1, 0, 0);
    public Vector3 bulletPosition = new Vector3(0, 0, 0);

    // Height and width variables for destroying off screen
    private Camera cam;
    private float height;
    private float width;

    // Use this for initialization
    void Start ()
    {
        // Set direction and velocity
        direction = transform.rotation * direction;
        velocity += direction * .15f;

        // Set height and width
        cam = Camera.main;
        height = 2f * cam.orthographicSize;
        width = height * cam.aspect;
    }
	
	// Update is called once per frame
	void Update ()
    {
        // Update position
        bulletPosition += velocity * Time.deltaTime;
        transform.position += bulletPosition;

        DestroyOffScreen();
	}

    /// <summary>
    /// Destroys bullet if it goes off screen
    /// </summary>
    public void DestroyOffScreen()
    {
        if (transform.position.x < (((width / 2) * -1) - 10))
        {
            Destroy(gameObject);
        }

        else if (transform.position.x > ((width / 2) + 10))
        {
            Destroy(gameObject);
        }

        else if (transform.position.y < (((height / 2) * -1) -10))
        {
            Destroy(gameObject);
        }

        else if (transform.position.y > ((height / 2) + 10))
        {
            Destroy(gameObject);
        }
    }
}
