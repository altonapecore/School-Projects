﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    // Variables for moving the object
    public float angleOfRotation;
    public float rotationSpeed;
    public Vector3 objectPosition;
    public Vector3 direction = new Vector3(1, 0, 0);
    public Vector3 velocity = new Vector3(0, 0, 0);

    // Height and width variables
    private Camera cam;
    private float height;
    private float width;

    // Use this for initialization
    void Start ()
    {
        // Set up the height and width for screen wrapping
        cam = Camera.main;
        height = 2f * cam.orthographicSize;
        width = height * cam.aspect;

        // Set up what direction the object is going
        direction = transform.rotation * direction;
        velocity += direction;

        objectPosition = new Vector3(transform.position.x, transform.position.y, 0);
    }
	
	// Update is called once per frame
	void Update ()
    {
        // update rotation and position
        angleOfRotation += rotationSpeed;
        objectPosition += velocity * Time.deltaTime;

        // Rotate object
        transform.rotation = Quaternion.Euler(0, 0, angleOfRotation);

        // Move object
        transform.position = objectPosition;

        StayOnScreen();
	}

    /// <summary>
    /// Makes sure that the object stays on screen and wraps
    /// </summary>
    public void StayOnScreen()
    {
        if (objectPosition.x < ((width / 2) * -1))
        {
            objectPosition.x = (width / 2);
        }

        else if (objectPosition.x > (width / 2))
        {
            objectPosition.x = ((width / 2) * -1);
        }

        if (objectPosition.y < ((height / 2) * -1))
        {
            objectPosition.y = (height / 2);
        }

        else if (objectPosition.y > (height / 2))
        {
            objectPosition.y = ((height / 2) * -1);
        }
    }
}
