﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vehicle : MonoBehaviour {

    public float rateOfAccel;
    public float maxSpeed;                                  // Limit mag of vel
    public float rotationSpeed;
    public float angleOfRotation;                           // 0
    public Vector3 vehiclePosition = new Vector3(0, 0, 0);  // Vector3.zero
    public Vector3 direction = new Vector3(1, 0, 0);        // Right, 0 degrees
    public Vector3 velocity = new Vector3(0, 0, 0);
    public Vector3 acceleration = new Vector3(0, 0, 0);

    private Camera cam;
    private float height;
    private float width;

    public GameObject bullet;

    // Use this for initialization
    void Start()
    {
        cam = Camera.main;
        height = 2f * cam.orthographicSize;
        width = height * cam.aspect;
    }

    // Update is called once per frame
    void Update()
    {
        // Separate into methods
        RotateVehicle();

        Drive();

        SetTransform();

        StayOnScreen();

    }

    /// <summary>
    /// 
    /// </summary>
    public void RotateVehicle()
    {
        // left arrow = 1 degree to left
        // right arrow = 1 degree to right
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            direction = Quaternion.Euler(0, 0, rotationSpeed) * direction;
            angleOfRotation += rotationSpeed;
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            angleOfRotation -= rotationSpeed;
            direction = Quaternion.Euler(0, 0, -rotationSpeed) * direction;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public void Drive()
    {
        // Add acceleration to velocity if up arrow key is down
        if (Input.GetKey(KeyCode.UpArrow))
        {
            acceleration = rateOfAccel * direction;

            velocity += acceleration * Time.deltaTime;
        }

        // If key is not down and there is acceleration, decelerate
        else
        {
            velocity = velocity * (0.9f * Time.deltaTime);
        }

        // Limit vel vector with ClampMagnitude
        velocity = Vector3.ClampMagnitude(velocity, maxSpeed);

        // Add vel to position
        vehiclePosition += velocity * Time.deltaTime;
    }

    /// <summary>
    /// 
    /// </summary>
    public void SetTransform()
    {
        // Rotate the vehicle to face correct direction
        transform.rotation = Quaternion.Euler(0, 0, angleOfRotation);

        // Position vehicle ("Draw it")
        transform.position = vehiclePosition;
    }

    /// <summary>
    /// Make sure the vehicle stays on screen by wrapping
    /// </summary>
    public void StayOnScreen()
    {
        if (vehiclePosition.x < ((width / 2) * -1))
        {
            vehiclePosition.x = (width / 2);
        }

        else if (vehiclePosition.x > (width / 2))
        {
            vehiclePosition.x = ((width / 2) * -1);
        }

        if (vehiclePosition.y < ((height / 2) * -1))
        {
            vehiclePosition.y = (height / 2);
        }

        else if (vehiclePosition.y > (height / 2))
        {
            vehiclePosition.y = ((height / 2) * -1);
        }
    }

    /// <summary>
    /// Shoot a bullet where the vehicle is
    /// </summary>
    /// <returns> The bullet that was fired </returns>
    public GameObject Fire()
    {
        return Instantiate(bullet, vehiclePosition, Quaternion.Euler(0, 0, angleOfRotation));
    }
}
