﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndGameButton : MonoBehaviour
{

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    // If the mouse is clicked on this button, close the game
    void OnMouseDown()
    {
        Application.Quit();
    }
}
