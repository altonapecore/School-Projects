﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonScript : MonoBehaviour
{

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    /// <summary>
    /// When the mouse is clicked load up the game scene
    /// </summary>
    void OnMouseDown()
    {
        SceneManager.LoadScene("Asteroids");
    }
}
