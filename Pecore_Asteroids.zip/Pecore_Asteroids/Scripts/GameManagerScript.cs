﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// An enum for what level it is
public enum Level
{
    one,
    two,
    three
}
public class GameManagerScript : MonoBehaviour
{
    #region Variables
    // GameObjects that will be used for spawining and keeping track of the game
    public GameObject vehicle;
    public GameObject largeAsteroid;
    public GameObject smallAsteroid;
    public GameObject ufo;
    public GameObject bullet;

    // List of all the objects in the game
    public List<GameObject> bigAsteroids;
    public List<GameObject> ufos;
    public List<GameObject> smallAsteroids;
    public List<GameObject> bullets;
    public List<GameObject> ufoBullets;

    // A reference to the class that does the collision equations
    public CollisionManager collision;

    // An x and y variable to be used for spawn positions
    public float x;
    public float y;

    // An enum of what level it currently is
    public Level level;

    // A timer for limiting bullet firing
    public float bulletTimer;
    // A timer for handling invincibility
    public float invincibilityTimer;
    // A timer for limiting ufo bullet firing
    public float ufoBulletTimer;

    // Ship lives
    public int lives;
    // A bool used in collisions to see if the ship's bullet hit an enemy
    public bool bulletHit;
    // A bool used in collisions to see if an enemy or enemy's bullet hit the ship
    public bool shipHit;
    // A bool to see if the ship is invincible
    public bool invincible;
    // A static int to represent the score
    // It's static because it is referenced in a different scene
    public static int score;
    #endregion

    #region Start
    // Use this for initialization
    void Start ()
    {
        // Initialize the collision script
        collision = GetComponent<CollisionManager>();

        // Set the timers to 0
        bulletTimer = 0;
        invincibilityTimer = 0;

        // Set ship lives to 3 
        lives = 3;

        // Initialize the lists
        bigAsteroids = new List<GameObject>();
        smallAsteroids = new List<GameObject>();
        ufos = new List<GameObject>();
        bullets = new List<GameObject>();
        ufoBullets = new List<GameObject>();

        // Make the enemies at level one
        MakeEnemies(level);

        // Set both collision bools to false, as well as invincibility
        bulletHit = false;
        shipHit = false;
        invincible = false;
    }
    #endregion

    #region Update
    // Update is called once per frame
    void Update ()
    {
        // Add how long the last frame took and add it to the timer
        bulletTimer += Time.deltaTime;

        // If space is pressed and the timer is past half a second, fire and set timer to 0
        if (Input.GetKeyDown(KeyCode.Space) && bulletTimer >= .5f)
        {
            bullets.Add(vehicle.GetComponent<Vehicle>().Fire());
            bulletTimer = 0;
        }

        // Run the collision management method
        CollisionManagement();

        // If there are no enemies left, set up the next level
        if(ufos.Count == 0 && bigAsteroids.Count == 0 && smallAsteroids.Count == 0)
        {
            NextLevel(level);
        }

        // If invincible is true, turn your ship red and add to the invincibility timer
        // If the timer is more than 5 seconds, turn invincibility off and reset the timer
        if (invincible)
        {
            Renderer rend = vehicle.GetComponent<Renderer>();
            rend.material.SetColor("_Color", Color.red);
            invincibilityTimer += Time.deltaTime;
            if( invincibilityTimer > 5)
            {
                rend.material.SetColor("_Color", Color.white);
                invincible = false;
                invincibilityTimer = 0;
            }
        }

        // Add to the ufo bullet timer, and if it is past 2 seconds fire a bullet, add it to the ufo bullet list, and set the timer to 0
        ufoBulletTimer += Time.deltaTime;
        if (ufoBulletTimer > 2)
        {
            for(int i = 0; i < ufos.Count; i++)
            {
                ufoBullets.Add(ufos[i].GetComponent<UfoShoot>().Fire());
                ufoBulletTimer = 0;
            }
        }
    }
    #endregion

    #region MakeEnemies
    /// <summary>
    /// Makes enemies based on what level it is
    /// </summary>
    /// <param name="currentLevel"> The current level of the game</param>
    public void MakeEnemies(Level currentLevel)
    {
        switch (currentLevel)
        {
            case Level.one:
                // Make 3 asteroids with random placement along the outer border of the game
                for(int i = 0; i < 3; i++)
                {
                    x = Random.Range(-.900f, .900f) * 10;

                    if(x < -6.0f || x > 6.0f)
                    {
                        y = Random.Range(-.500f, .500f) * 10;
                    }

                    else
                    {
                        y = Random.Range(-.500f, -.300f) * 10;
                    }

                    // Add the asteroid to the list of asteroids
                    bigAsteroids.Add(Instantiate(largeAsteroid, new Vector3(x, y, 0), Quaternion.Euler(0, 0, Random.Range(0, 361))));
                    Debug.Log("x" + x);
                    Debug.Log("y" + y);
                }
                break;

            case Level.two:
                // Make 5 asteroids with random placement along the outer border of the game
                for (int i = 0; i < 5; i++)
                {
                    x = Random.Range(-.900f, .900f) * 10;

                    if (x < -6.0f || x > 6.0f)
                    {
                        y = Random.Range(-.500f, .500f) * 10;
                    }

                    else
                    {
                        y = Random.Range(-.500f, -.300f) * 10;
                    }

                    // Add the asteroid to the list of asteroids
                    bigAsteroids.Add(Instantiate(largeAsteroid, new Vector3(x, y, 0), Quaternion.Euler(0, 0, Random.Range(0, 361))));
                    Debug.Log("x" + x);
                    Debug.Log("y" + y);
                }

                // Set up the x and y of the ufo
                x = Random.Range(-.900f, .900f) * 10;

                if (x < -6.0f || x > 6.0f)
                {
                    y = Random.Range(-.500f, .500f) * 10;
                }

                else
                {
                    y = Random.Range(-.500f, -.300f) * 10;
                }

                // Add the ufo to the list
                ufos.Add(Instantiate(ufo, new Vector3(x, y, 0), Quaternion.Euler(0, 0, Random.Range(0, 361))));
                break;

            case Level.three:
                // Make 5 asteroids with random placement along the border
                for (int i = 0; i < 5; i++)
                {
                    x = Random.Range(-.900f, .900f) * 10;

                    if (x < -6.0f || x > 6.0f)
                    {
                        y = Random.Range(-.500f, .500f) * 10;
                    }

                    else
                    {
                        y = Random.Range(-.500f, -.300f) * 10;
                    }

                    // Add asteroids to the list
                    bigAsteroids.Add(Instantiate(largeAsteroid, new Vector3(x, y, 0), Quaternion.Euler(0, 0, Random.Range(0, 361))));
                    Debug.Log("x" + x);
                    Debug.Log("y" + y);
                }

                // Make 5 ufos with random placement along the border
                for (int i = 0; i < 5; i++)
                {
                    x = Random.Range(-.900f, .900f) * 10;

                    if (x < -6.0f || x > 6.0f)
                    {
                        y = Random.Range(-.500f, .500f) * 10;
                    }

                    else
                    {
                        y = Random.Range(-.500f, -.300f) * 10;
                    }

                    // Add ufos to the list
                    ufos.Add(Instantiate(ufo, new Vector3(x, y, 0), Quaternion.Euler(0, 0, Random.Range(0, 361))));
                    Debug.Log("x" + x);
                    Debug.Log("y" + y);
                }
                break;
        }
    }
    #endregion

    #region MakeSmallAsteroids
    /// <summary>
    /// Makes small asteroids based on the parent's position
    /// </summary>
    /// <param name="enemyParent"> The parent where the small asteroids will be spawned</param>
    public void MakeSmallAsteroids(GameObject enemyParent)
    {
        // Make the x and y that of the parent
        x = enemyParent.transform.position.x;
        y = enemyParent.transform.position.y;

        // Instantiate two small asteroids and add them to their respective list
        smallAsteroids.Add(Instantiate(smallAsteroid, new Vector3(x, y, 0), Quaternion.Euler(0, 0, Random.Range(0, 361))));
        smallAsteroids.Add(Instantiate(smallAsteroid, new Vector3(x, y, 0), Quaternion.Euler(0, 0, Random.Range(0, 361))));
    }
    #endregion

    #region NextLevel
    /// <summary>
    /// Sets up the next level of the game
    /// </summary>
    /// <param name="currentlevel"> The level that was just beaten </param>
    public void NextLevel(Level currentlevel)
    {
        // Checks to see what level it is and then loads the next one
        if(currentlevel == Level.one)
        {
            // Change level
            level = Level.two;

            // Spawn in enemies
            MakeEnemies(level);

            // Destroy bullets and set bullet timer to 0
            for(int i = 0; i < bullets.Count; i++)
            {
                Destroy(bullets[i]);
            }
            bullets.Clear();
            bulletTimer = 0;

            // Center ship and set everything to the way it was before
            vehicle.GetComponent<Vehicle>().vehiclePosition = Vector3.zero;
            vehicle.GetComponent<Vehicle>().velocity = Vector3.zero;
            vehicle.GetComponent<Vehicle>().acceleration = Vector3.zero;
            vehicle.GetComponent<Vehicle>().direction = Vector3.right;
            vehicle.GetComponent<Vehicle>().angleOfRotation = 0;
        }

        else if(currentlevel == Level.two)
        {
            // Change level
            level = Level.three;

            // Spawn in enemies
            MakeEnemies(level);

            // Destroy bullets and set bullet timer to 0
            for (int i = 0; i < bullets.Count; i++)
            {
                Destroy(bullets[i]);
            }
            bullets.Clear();
            bulletTimer = 0;

            // Center ship and set everything to the way it was before
            vehicle.GetComponent<Vehicle>().vehiclePosition = Vector3.zero;
            vehicle.GetComponent<Vehicle>().velocity = Vector3.zero;
            vehicle.GetComponent<Vehicle>().acceleration = Vector3.zero;
            vehicle.GetComponent<Vehicle>().direction = Vector3.right;
            vehicle.GetComponent<Vehicle>().angleOfRotation = 0;
        }

        else
        {
            // Change scene to win scene
            SceneManager.LoadScene("Win Screen");
        }
    }
    #endregion

    #region ShipDied
    /// <summary>
    /// Runs if the ship collides with an enemy or enemy's bullet
    /// </summary>
    public void ShipDied()
    {
        // Subtract lives and set invincible to true
        lives--;
        invincible = true;

        // Center ship and set everything to the way it was before
        vehicle.GetComponent<Vehicle>().vehiclePosition = Vector3.zero;
        vehicle.GetComponent<Vehicle>().velocity = Vector3.zero;
        vehicle.GetComponent<Vehicle>().acceleration = Vector3.zero;
        vehicle.GetComponent<Vehicle>().direction = Vector3.right;
        vehicle.GetComponent<Vehicle>().angleOfRotation = 0;

        // If there are no lives left go to the lose scene
        if (lives == 0)
        {
            SceneManager.LoadScene("Lose Screen");
        }
    }
    #endregion

    #region OnGUI
    /// <summary>
    /// Prints out lives and current score
    /// </summary>
    public void OnGUI()
    {
        // Prints out how many lives are left
        GUI.Box(new Rect(10, 10, 100, 50), "Lives: " + lives.ToString() + "\nScore :" + score.ToString());
    }
    #endregion

    #region CollisionManagement
    /// <summary>
    /// Checks for collisions
    /// </summary>
    public void CollisionManagement()
    {
        // Run collisions
        // Checking each bullet
        for(int i = 0; i < bullets.Count; i++)
        {
            // If the bullet is null then remove it and subtract the index
            if (bullets[i] == null)
            {
                bullets.Remove(bullets[i]);
                i--;
            }
            // Make sure big asteroid list isn't empty
            if (bigAsteroids.Count > 0)
            {
                // Checking each big asteroid
                for(int j = 0; j < bigAsteroids.Count; j++)
                {
                    // Makes sure that the asteroid is not null
                    if (bigAsteroids[j] != null && i >= 0)
                    {
                        // Make sure that there are bullets
                        if (bullets.Count > 0)
                        {
                            // Check for a collision
                            bulletHit = collision.BulletCollision(bullets[i], bigAsteroids[j]);
                            // If there is a collision, remove both the bullet and asteroid, subtract their indexes, and spawn small asteroids
                            // Also set bulletHit to false and add 20 to the score
                            if (bulletHit)
                            {
                                MakeSmallAsteroids(bigAsteroids[j]);
                                Destroy(bigAsteroids[j]);
                                bigAsteroids.Remove(bigAsteroids[j]);
                                j--;
                                bulletHit = false;
                                Destroy(bullets[i]);
                                bullets.Remove(bullets[i]);
                                i--;
                                score += 20;
                            }
                        }
                    }
                }
            }

            if (level == Level.two || level == Level.three)
            {
                // Loop through each ufo
                for(int j = 0; j < ufos.Count; j++)
                {
                    // Make sure that the ufo is not null
                    if (ufos[j] != null && i >= 0)
                    {
                        // Make sure that there are bullets
                        if (bullets.Count > 0)
                        {
                            // Check for collision
                            bulletHit = collision.BulletCollision(bullets[i], ufos[j]);
                            // If there is a collision, remove both the bullet and asteroid, subtract their indexes, and spawn small asteroids
                            // Also set bulletHit to false and add 100 to the score
                            if (bulletHit)
                            {
                                MakeSmallAsteroids(ufos[j]);
                                Destroy(ufos[j]);
                                ufos.Remove(ufos[j]);
                                j--;
                                bulletHit = false;
                                Destroy(bullets[i]);
                                bullets.Remove(bullets[i]);
                                i--;
                                score += 100;
                            }
                        }
                    }
                }
            }

            if (smallAsteroids.Count > 0)
            {
                // Loop through each small asteroid
                for(int j = 0; j < smallAsteroids.Count; j++)
                {
                    // Make sure the asteroid is false
                    if (smallAsteroids[j] != null && i >= 0)
                    {
                        // Make sure there are bullets
                        if (bullets.Count > 0)
                        {
                            // Check for collisions
                            bulletHit = collision.BulletCollision(bullets[i], smallAsteroids[j]);
                            // If there is a collision, remove both the bullet and asteroid, subtract their indexes
                            // Also set bulletHit to false and add 50 to the score
                            if (bulletHit)
                            {
                                Destroy(smallAsteroids[j]);
                                smallAsteroids.Remove(smallAsteroids[j]);
                                j--;
                                bulletHit = false;
                                Destroy(bullets[i]);
                                bullets.Remove(bullets[i]);
                                i--;
                                score += 50;
                            }
                        }
                    }
                }
            }
        }

        // Loops through ufo bullets
        for(int i = 0; i < ufoBullets.Count; i++)
        {
            if(ufoBullets[i] != null && i >= 0)
            {
                // If the ship is not invincible, check for a collision
                if (!invincible)
                {
                    shipHit = collision.ShipCollision(vehicle, ufoBullets[i]);
                }
                // If there is a collision, run shipDied, set the bool to false, get rid of the bullet, and subtract the index
                if (shipHit)
                {
                    ShipDied();
                    shipHit = false;
                    Destroy(ufoBullets[i]);
                    ufoBullets.Remove(ufoBullets[i]);
                    i--;
                }
            }
        }

        // Loop through big asteroids
        for(int i = 0; i < bigAsteroids.Count; i++)
        {
            // If the ship is not invincible, check for a collision
            if (!invincible)
            {
                shipHit = collision.ShipCollision(vehicle, bigAsteroids[i]);
            }
            // If there is a collision, run shipDied and set the bool to false
            if (shipHit)
            {
                ShipDied();
                shipHit = false;
            }
        }

        // Loop through small asteroids
        for(int i = 0; i < smallAsteroids.Count; i++)
        {
            // If the ship is not invincible, check for a collision
            if (!invincible)
            {
                shipHit = collision.ShipCollision(vehicle, smallAsteroids[i]);
            }
            // If there is a collision, run shipDied and set the bool to false
            if (shipHit)
            {
                ShipDied();
                shipHit = false;
            }
        }

        // Loop through ufos
        for(int i = 0; i < ufos.Count; i++)
        {
            // If ship is not invincible, check for a collision
            if (!invincible)
            {
                shipHit = collision.ShipCollision(vehicle, ufos[i]);
            }
            // If there is a collision, run shipDied and set the bool to false
            if (shipHit)
            {
                ShipDied();
                shipHit = false;
            }
        }
    }
    #endregion
}
